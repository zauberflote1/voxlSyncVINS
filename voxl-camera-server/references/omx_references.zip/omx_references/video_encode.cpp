/**
  @file vtest/encode/src/video_encode.cpp

  Test application that uses a OpenMAX component, a generic video encoder.
  The application receives an video stream (.yuv) encode in h264 or h265 Video format(.264 or .265).

  $Date$
  Revision $Rev$
  Author $Author$
**/

#include "video_encode.h"

/** defining global declarations */

#define COMPONENT_ENC_AVC "OMX.qcom.video.encoder.avc"
#define COMPONENT_ENC_HEVC "OMX.qcom.video.encoder.hevc"

#define COMPONENT_NAME_BASE_LEN 22

#define TEST_OMX_INIT_STRUCT(_s_, _name_)             \
    memset((_s_), 0x0, sizeof(_name_));          \
    (_s_)->nSize = sizeof(_name_);               \
    (_s_)->nVersion.nVersion = OMX_SPEC_VERSION


#define TEST_FAILED1(rv, fmt, ...)  \
    if(rv != OMX_ErrorNone) \
    {                           \
        //printf(fmt"", ## __VA_ARGS__); \
        PRINT_ERR(fmt"", ## __VA_ARGS__); \
        return rv;           \
    }

#define Log2(number, power)  { OMX_U32 temp = number; power = 0; \
    while ( (0 == (temp & 0x1)) &&  power < 16) { temp >>=0x1; power++; } }
#define FractionToQ16(q, num, den) { OMX_U32 power; Log2(den, power); q = num << (16 - power); }
// #define ALIGN(x, to_align) ((((unsigned long) x) + (to_align - 1)) & ~(to_align - 1))


OMX_CALLBACKTYPE videoenccallbacks = {
    .EventHandler = videoencEventHandler,
    .EmptyBufferDone = videoencEmptyBufferDone,
    .FillBufferDone = videoencFillBufferDone
  };

/** global variables */
static appPrivateType* appPriv;

static char *input_file, *output_file;
static FILE *infile, *outfile;
static OMX_BOOL bEOS = OMX_FALSE;
static OMX_U32 in_width = 320;
static OMX_U32 in_height = 240;
static OMX_VIDEO_CODINGTYPE s_eEncCodec = OMX_VIDEO_CodingAVC;
static CodecProfileType s_eEncProfile = AVCProfileMain;
static OMX_VIDEO_CONTROLRATETYPE s_eControlRate = OMX_Video_ControlRateDisable;

static OMX_U32 frame_rate = 30;
static OMX_U32 buffer_in_size = 430080;
static OMX_U32 buffer_out_size = 307200;
static OMX_U32 m_nInputBufferCount = 3;
static OMX_U32 m_nOutputBufferCount = 3;
OMX_U32 m_frameSize = in_width*in_height*3/2;

static VideoStreamParser m_StreamParser;
static VideoSessionStaticConfig m_sStaticConfig;
static OMX_S32 m_nInCopyBufSize;


/** used with video encoder */
static OMX_BUFFERHEADERTYPE **pInBuffer = NULL;
static OMX_BUFFERHEADERTYPE **pOutBuffer = NULL;
static struct CodecConfigType  m_sCodecConfig;

/** help display */
void display_help() {
  printf("\n");
  printf("Usage:\n");
  printf("vtest_encode -o outfile [-W 320] [-H 240] [-r 0] [-h] [-f frameRate] -i inputFile\n");
  printf("\n");
  printf("       -i infile : Input yuv file name\n");
  printf("       -o outfile: If this is set, the output file should be h264 or h265 format\n");
  printf("\n");
  printf("       -h: Displays this help\n");
  printf("\n");
  printf("           The available output formats are -f 264 or -f 265 \n");
  printf("       -W width\n");
  printf("       -H Height\n");
  printf("       -f frame per second, the available value is 30 or 60\n");
  printf("       -r eControlRate, 0:RC_OFF 1:VBR_VFR 2:VBR_CFR 3:CBR_VFR 4:CBR_CFR 5:MBR_RC\n");
  printf("\n");
  exit(1);
}

void vtest_Config() {
    static const OMX_STRING pInFileName = (OMX_STRING)"";

    // set some default values
    memset(&m_sCodecConfig, 0, sizeof(m_sCodecConfig));
    m_sCodecConfig.eCodec = s_eEncCodec;
    m_sCodecConfig.eFileType = FILE_TYPE_ARBITRARY_BYTES;
    m_sCodecConfig.eCodecProfile = s_eEncProfile;
    m_sCodecConfig.eCodecLevel = DefaultLevel;
    m_sCodecConfig.eControlRate = s_eControlRate;
    m_sCodecConfig.nFrameWidth = in_width;
    m_sCodecConfig.nFrameHeight = in_height;
    m_sCodecConfig.nOutputFrameWidth = m_sCodecConfig.nFrameWidth;
    m_sCodecConfig.nOutputFrameHeight = m_sCodecConfig.nFrameHeight;
    m_sCodecConfig.nDVSXOffset = 0;
    m_sCodecConfig.nDVSYOffset = 0;
    m_sCodecConfig.nBitrate = INVALID_VALUE;
    m_sCodecConfig.nFramerate = frame_rate;
    m_sCodecConfig.nTimeIncRes = 30;
    m_sCodecConfig.nRotation = 0;
    m_sCodecConfig.nMirror = 0;
    m_sCodecConfig.nInBufferCount = 3;
    m_sCodecConfig.nOutBufferCount = 3;
    m_sCodecConfig.nHECInterval = 0;
    m_sCodecConfig.bEnableSliceDeliveryMode = OMX_FALSE;
    m_sCodecConfig.nResyncMarkerSpacing = 0;
    m_sCodecConfig.eResyncMarkerType = RESYNC_MARKER_NONE;
    m_sCodecConfig.nIntraRefreshMBCount = 0;
    m_sCodecConfig.nFrames = 100;  // INT_MAX;  // frame num of encoded
    m_sCodecConfig.bEnableShortHeader = OMX_FALSE;
    m_sCodecConfig.nIntraPeriod = m_sCodecConfig.nFramerate * 2;
    m_sCodecConfig.nMinQp = INVALID_VALUE;
    m_sCodecConfig.nMaxQp = INVALID_VALUE;
    m_sCodecConfig.nIDRPeriod = INVALID_VALUE;
    m_sCodecConfig.nBFrames = 0xDEAD;
    m_sCodecConfig.nPFrames = 0;
    m_sCodecConfig.bProfileMode = OMX_FALSE;
    m_sCodecConfig.bCABAC = OMX_FALSE;
    m_sCodecConfig.nDeblocker = INVALID_VALUE;
    m_sCodecConfig.id = 0;
    m_sCodecConfig.cancel_flag = 1;
    m_sCodecConfig.type = 0;
    m_sCodecConfig.quincunx_sampling_flag = 0;
    m_sCodecConfig.content_interpretation_type = 0;
    m_sCodecConfig.spatial_flipping_flag = 0;
    m_sCodecConfig.frame0_flipped_flag = 0;
    m_sCodecConfig.field_views_flag = 0;
    m_sCodecConfig.current_frame_is_frame0_flag = 0;
    m_sCodecConfig.frame0_self_contained_flag = 0;
    m_sCodecConfig.frame1_self_contained_flag = 0;
    m_sCodecConfig.frame0_grid_position_x = 0;
    m_sCodecConfig.frame0_grid_position_y = 0;
    m_sCodecConfig.frame1_grid_position_x = 0;
    m_sCodecConfig.frame1_grid_position_y = 0;
    m_sCodecConfig.reserved_byte = 0;
    m_sCodecConfig.repetition_period = 0;
    m_sCodecConfig.extension_flag = 0;
    m_sCodecConfig.nLTRMode = 0;
    m_sCodecConfig.nLTRCount = 0;
    m_sCodecConfig.nLTRPeriod = 0;
    m_sCodecConfig.nPriority = 0xDEAD;
    m_sCodecConfig.nLowLatency = 0xDEAD;
    m_sCodecConfig.m_nPrefixHeaderMode = 0xDEAD;
    m_sCodecConfig.bSecureSession = OMX_FALSE;
    m_sCodecConfig.bMdpFrameSource = OMX_FALSE;
    m_sCodecConfig.bInsertInbandVideoHeaders = OMX_FALSE;
    m_sCodecConfig.bInsertAUDelimiters = OMX_FALSE;
    m_sCodecConfig.ePlaybackMode = DynamicBufferMode;
    m_sCodecConfig.nAdaptiveWidth = m_sCodecConfig.nFrameWidth;
    m_sCodecConfig.nAdaptiveHeight = m_sCodecConfig.nFrameHeight;
    m_sCodecConfig.bRotateDisplay = OMX_FALSE;
    m_sCodecConfig.eDecoderPictureOrder = QOMX_VIDEO_DISPLAY_ORDER;
    m_sCodecConfig.eSinkType = Unknown_Sink;
    m_sCodecConfig.bMetaMode = OMX_TRUE;
    m_sCodecConfig.eMetaBufferType = CameraSource;
    m_sCodecConfig.eYuvColorSpace = ITUR601;
    m_sCodecConfig.nIDRPeriod = m_sCodecConfig.nIntraPeriod;
    m_sCodecConfig.bDownScalar = OMX_FALSE;
    m_sCodecConfig.ePostProcType = DefaultMemcopy;
    m_sCodecConfig.nInputColorFormat = QOMX_COLOR_FORMATYUV420PackedSemiPlanar32m;
    m_sCodecConfig.nOutputColorFormat = QOMX_COLOR_FORMATYUV420PackedSemiPlanar32m;
    m_sCodecConfig.nDropHierPLayer = -1;
    m_sCodecConfig.bDeinterlace = OMX_FALSE;
    m_sCodecConfig.nCurrentTestNum = 0;
    m_sCodecConfig.nPictureTypeDecode = 0;
    m_sCodecConfig.nMaxHPLayers = 0;
    m_sCodecConfig.nRectLeft = 0;
    m_sCodecConfig.nRectTop = 0;
    m_sCodecConfig.nRectWidth = 0;
    m_sCodecConfig.nRectHeight = 0;
    m_sCodecConfig.nBaseLayerId = 0;
    m_sCodecConfig.nConfigQp = 0;
    m_sCodecConfig.nSarWidth = 0;
    m_sCodecConfig.nSarHeight = 0;
    m_sCodecConfig.bForceCompressedForDPB = OMX_FALSE;
    m_sCodecConfig.nBlurWidth = 0;
    m_sCodecConfig.nBlurHeight = 0;
    m_sCodecConfig.pExtradataProperties = NULL;
    m_sCodecConfig.cCrcFileName[0] = '\0';
    m_sCodecConfig.cMISRFileName[0] = '\0';
    m_sCodecConfig.nHierPNumLayers = 1;
    m_sCodecConfig.nMaxHPLayers = 1;
    m_sCodecConfig.sHybridHP.nHpLayers = 1;
    m_sCodecConfig.sColorAspects.mRange = android::ColorAspects::Range::RangeUnspecified;
    m_sCodecConfig.sColorAspects.mPrimaries = \
        android::ColorAspects::Primaries::PrimariesUnspecified;
    m_sCodecConfig.sColorAspects.mTransfer = \
        android::ColorAspects::Transfer::TransferUnspecified;
    m_sCodecConfig.sColorAspects.mMatrixCoeffs = \
        android::ColorAspects::MatrixCoeffs::MatrixUnspecified;
    m_sCodecConfig.nStressTime = 0;
    // default dynamic config
    // m_sDynamicConfig.nIFrameRequestPeriod = 0;
    // m_sDynamicConfig.nUpdatedBitrate = m_sCodecConfig.nBitrate;
    // m_sDynamicConfig.nUpdatedFramerate = m_sCodecConfig.nFramerate;
    // m_sDynamicConfig.nUpdatedFrames = m_sCodecConfig.nFrames;
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
OMX_ERRORTYPE vtest_SetPortParams(OMX_U32 ePortIndex,
        OMX_U32 nWidth, OMX_U32 nHeight, OMX_U32 nBufferCountMin,
        OMX_U32 nFrameRate, OMX_U32 *nBufferSize, OMX_U32 *nBufferCount) {
    OMX_ERRORTYPE result = OMX_ErrorNone;
    OMX_PARAM_PORTDEFINITIONTYPE sPortDef;
    TEST_OMX_INIT_STRUCT(&sPortDef, OMX_PARAM_PORTDEFINITIONTYPE);

    if ((nBufferSize == NULL) || (nBufferCount == NULL)) {
        PRINT_MSG("invalid input");
        return OMX_ErrorBadParameter;
    }

    sPortDef.nPortIndex = ePortIndex;
    result = OMX_GetParameter(appPriv->videoenchandle,
            OMX_IndexParamPortDefinition, (OMX_PTR)&sPortDef);
    if (result != OMX_ErrorNone) {
        PRINT_ERR("fail to OMX_GetParameter() \n");
    }

    FractionToQ16(sPortDef.format.video.xFramerate, static_cast<int>(nFrameRate * 2), 2);

    // setup frame width/height
    sPortDef.format.video.nFrameWidth = nWidth;
    sPortDef.format.video.nFrameHeight = nHeight;
    if (ePortIndex == 0) {  // for encode
        // sPortDef.format.video.eColorFormat = (OMX_COLOR_FORMATTYPE)m_nColorFormat;
        sPortDef.format.video.eColorFormat = \
        (OMX_COLOR_FORMATTYPE)OMX_QCOM_COLOR_FormatYUV420PackedSemiPlanar32m;
    }


    OMX_INIT_STRUCT_SIZE(&sPortDef, OMX_PARAM_PORTDEFINITIONTYPE);
    result = OMX_SetParameter(appPriv->videoenchandle,
            OMX_IndexParamPortDefinition, (OMX_PTR)&sPortDef);
    if (result != OMX_ErrorNone) {
        PRINT_ERR("Error: SET OMX_IndexParamPortDefinition");
    }

    result = OMX_GetParameter(appPriv->videoenchandle,
            OMX_IndexParamPortDefinition, (OMX_PTR)&sPortDef);
    if (result != OMX_ErrorNone) {
        PRINT_ERR("Error: GET OMX_IndexParamPortDefinition");
    }

    if ((sPortDef.format.video.nFrameWidth != nWidth) ||
        (sPortDef.format.video.nFrameHeight != nHeight)) {
        PRINT_ERR("width %u != %u or height %u != %u\n",
                (unsigned int)sPortDef.format.video.nFrameWidth, (unsigned int)nWidth,
                (unsigned int)sPortDef.format.video.nFrameHeight, (unsigned int)nHeight);
    }

    // setup buffer count
    if (nBufferCountMin < sPortDef.nBufferCountMin) {
        PRINT_MSG("nBufferCount %u too small overriding to %u",
            (unsigned int)nBufferCountMin, (unsigned int)sPortDef.nBufferCountMin);
        nBufferCountMin = MAX(sPortDef.nBufferCountMin, 9);
    }
    sPortDef.nBufferCountActual = sPortDef.nBufferCountMin = nBufferCountMin;

    OMX_INIT_STRUCT_SIZE(&sPortDef, OMX_PARAM_PORTDEFINITIONTYPE);
    result = OMX_SetParameter(appPriv->videoenchandle,
            OMX_IndexParamPortDefinition, (OMX_PTR)&sPortDef);
    if (result != OMX_ErrorNone) {
        PRINT_ERR("Error: SET OMX_IndexParamPortDefinition");
    }

    result = OMX_GetParameter(appPriv->videoenchandle,
            OMX_IndexParamPortDefinition, (OMX_PTR)&sPortDef);
    if (result != OMX_ErrorNone) {
        PRINT_ERR("Error: GET OMX_IndexParamPortDefinition");
    }

    if (nBufferCountMin != sPortDef.nBufferCountActual) {
        PRINT_ERR("Buffer reqs dont match...%u != %u\n",
                (unsigned int)nBufferCountMin, (unsigned int)sPortDef.nBufferCountActual);
    }

    PRINT_MSG("Port%d cfg, width %u, height %u, bufs %u, size %u",
            ePortIndex, (unsigned int)sPortDef.format.video.nFrameWidth,
            (unsigned int)sPortDef.format.video.nFrameHeight,
            (unsigned int)sPortDef.nBufferCountActual, (unsigned int)sPortDef.nBufferSize);

    *nBufferCount = sPortDef.nBufferCountActual;
    *nBufferSize = sPortDef.nBufferSize;

    return result;
}


void vtest_SetPort() {
    OMX_ERRORTYPE result;

    // vtest_encode config
    /* buffer requirements need to be called after all the parameters are set */
    // input buffer requirements
    result = vtest_SetPortParams(0,
          in_width, in_height,
          m_sCodecConfig.nOutBufferCount, m_sCodecConfig.nFramerate,
          &buffer_in_size, &m_nInputBufferCount);
    if (OMX_ErrorNone != result) {
    PRINT_ERR("Failed : SetPortParams for PORT_0");
    }


    // output buffer requirements
    result = vtest_SetPortParams(1,
          in_width, in_height,
          m_sCodecConfig.nOutBufferCount, m_sCodecConfig.nFramerate,
          &buffer_out_size, &m_nOutputBufferCount);
    if (OMX_ErrorNone != result) {
        PRINT_ERR("Failed : SetPortParams for PORT_1");
    }


// go to Idle, so we can allocate buffers
// result = SetState(OMX_StateIdle, OMX_FALSE);
// FAILED1(result, "Could not move to OMX_StateIdle!");
}


int  vtest_VideoStreamParse(void) {
    VideoStreamParser *m_pStreamParser = &m_StreamParser;
    struct CodecConfigType *pConfig = &m_sCodecConfig;

    OMX_U32 m_nColorFormat = pConfig->nInputColorFormat;
    OMX_U32 m_nFramerate = pConfig->nFramerate;
    char cInRoot[16];
    char cOutRoot[16];
    VideoResolution res;
    VidcStatus ret = VidcStatusSuccess;

    ret = VideoStreamParserInit(m_pStreamParser);
    if (ret) {
        PRINT_ERR("VideoStreamParserInit failed with %d!!", ret);
        return OMX_ErrorUndefined;
    }

    /* Configure stream parser with codec details*/
    // sBufferFormat is not valid for decoder
    m_sStaticConfig.sBufferFormat = ParseEnumValue(g_pColorFormat, pConfig->nInputColorFormat);
    m_sStaticConfig.sCodecType =  ParseEnumValue(g_pXmlOmxCodecMap, pConfig->eCodec);
    m_sStaticConfig.nFrameCnt = pConfig->nFrames;  // user it to encode
    PRINT_MSG(" sBufferFormat=%s, sCodeType=%s \n",
        m_sStaticConfig.sBufferFormat, m_sStaticConfig.sCodecType);
    PRINT_MSG(" nFrameCnt=%d \n", m_sStaticConfig.nFrameCnt);
    PRINT_MSG(" nInputColorFormat : 0x%x, m_nFramerate=%d \n",
        m_nColorFormat, m_nFramerate);

    ret = m_pStreamParser->Configure(m_pStreamParser, &m_sStaticConfig, cInRoot, FALSE,
        cOutRoot, pConfig->cInFileName, pConfig->cOutFileName);
    if (ret) {
        PRINT_ERR("VideoStreamParserConfigure failed with %d!!", ret);
        return OMX_ErrorUndefined;
    }

    res.nColorFmt = ParseEnum(reinterpret_cast<ConfigEnum*>(pYUVFormatMap),
        m_sStaticConfig.sBufferFormat);
    res.nWidth = pConfig->nFrameWidth;
    res.nHeight = pConfig->nFrameHeight;
    res.nStartX = 0;
    res.nStartY = 0;
    res.nCropWidth =  pConfig->nFrameWidth;
    res.nCropHeight = pConfig->nFrameHeight;
    res.nStride = pConfig->nFrameWidth;
    res.nScanlines = pConfig->nFrameHeight;

    if (res.nColorFmt == V4L2_PIX_FMT_NV12) {
        res.nStride = VENUS_Y_STRIDE(COLOR_FMT_NV12, pConfig->nFrameWidth);
        res.nScanlines = VENUS_Y_SCANLINES(COLOR_FMT_NV12, pConfig->nFrameHeight);
    } else if (res.nColorFmt == V4L2_PIX_FMT_SDE_Y_CBCR_H2V2_P010_VENUS) {
        res.nStride = VENUS_Y_STRIDE(COLOR_FMT_P010, pConfig->nFrameWidth);
        res.nScanlines = VENUS_Y_SCANLINES(COLOR_FMT_P010, pConfig->nFrameHeight);
    }

    if (V4L2_PIX_FMT_NV12 == res.nColorFmt) {
        m_nInCopyBufSize = (OMX_S32)GetFrameSize(m_nColorFormat, res.nStride, res.nScanlines);
    } else if (V4L2_PIX_FMT_SDE_Y_CBCR_H2V2_P010_VENUS == res.nColorFmt) {
        m_nInCopyBufSize = (OMX_S32)GetFrameSize(m_nColorFormat, res.nStride, res.nScanlines);
    } else {
        m_nInCopyBufSize = (OMX_S32)GetFrameSize(m_nColorFormat,
            pConfig->nFrameWidth, pConfig->nFrameHeight);
    }

    ret = m_pStreamParser->SetResolution(m_pStreamParser, res,
        (OMX_S32)GetFrameSize(m_nColorFormat, pConfig->nFrameWidth, pConfig->nFrameHeight));
    if (ret) {
        PRINT_ERR("VideoStreamParserSetResolution failed with %d!!", ret);
        return OMX_ErrorUndefined;
    }

    m_pStreamParser->SetFrameRate(m_pStreamParser, m_nFramerate, 1);  // return none

    PRINT_MSG(" nInputColorFormat : 0x%x, m_nFramerate=%d \n", m_nColorFormat, m_nFramerate);

    return OMX_ErrorNone;
}

OMX_VIDEO_CONTROLRATETYPE vtest_parseControlRate(OMX_U32 u32ControlRate) {
    OMX_VIDEO_CONTROLRATETYPE eCtRate = OMX_Video_ControlRateDisable;
    if (1 == u32ControlRate) {
        eCtRate = OMX_Video_ControlRateVariable;
    } else if (2 == u32ControlRate) {
        eCtRate = OMX_Video_ControlRateConstant;
    } else if (3 == u32ControlRate) {
        eCtRate = OMX_Video_ControlRateVariableSkipFrames;
    } else if (4 == u32ControlRate) {
        eCtRate = OMX_Video_ControlRateConstantSkipFrames;
    } else if (5 == u32ControlRate) {
        eCtRate = OMX_Video_ControlRateKhronosExtensions;
    } else if (6 == u32ControlRate) {
        eCtRate = OMX_Video_ControlRateVendorStartUnused;
    } else {
    }

    return eCtRate;
}

OMX_ERRORTYPE  vtest_check_user_params(int argc, char** argv) {
    int argn_dec = 1;
    int flagIsOutputExpected = 0;
    int flagIsInputExpected = 0;
    int flagOutputReceived = 0;
    int flagInputReceived = 0;
    int flagIsWidth = 0;
    int flagIsHeight = 0;
    int flagIsFPS = 0;
    int flagIsControlRate = 0;

    if (argc < 2) {
      display_help();
    }

    argn_dec = 1;
    while (argn_dec < argc) {
      if (*(argv[argn_dec]) == '-') {
        if (flagIsOutputExpected) {
          display_help();
        }
        switch (*(argv[argn_dec] + 1)) {
          case 'h' :
            display_help();
            break;
          case 'i':
            flagIsInputExpected = 1;
            break;
          case 'o':
            flagIsOutputExpected = 1;
            break;
          case 'W' :
            flagIsWidth = 1;
            break;
          case 'H' :
            flagIsHeight = 1;
            break;
          case 'f' :
            flagIsFPS = 1;
          case 'r' :
            flagIsControlRate = 1;
            break;
          default:
            display_help();
        }
      } else {
        if (flagIsOutputExpected) {
          if (strstr(argv[argn_dec], ".264") != NULL) {
            output_file = reinterpret_cast<char *>(malloc(strlen(argv[argn_dec]) + 1));
            // strcpy(output_file, argv[argn_dec]);
            snprintf(output_file, strlen(argv[argn_dec])+1, "%s", argv[argn_dec]);
            s_eEncCodec = OMX_VIDEO_CodingAVC;
            s_eEncProfile = AVCProfileMain;
          } else if (strstr(argv[argn_dec], ".265") != NULL) {
            output_file = reinterpret_cast<char *>(malloc(strlen(argv[argn_dec]) + 1));
            // strcpy(output_file, argv[argn_dec]);
            snprintf(output_file, strlen(argv[argn_dec])+1, "%s", argv[argn_dec]);
            s_eEncCodec = OMX_VIDEO_CodingHEVC;
            s_eEncProfile = HEVCProfileMain;
          } else {
            int k = 0;
            if (strstr(argv[argn_dec], ".")) {
              k = strlen(strstr(argv[argn_dec], "."));
            }
            output_file = reinterpret_cast<char *>(malloc(strlen(argv[argn_dec]) - k + 6));
            strncpy(output_file, argv[argn_dec], (strlen(argv[argn_dec]) - k));
            // strcat(output_file, ".264");
            strncpy(output_file + (strlen(argv[argn_dec]) - k), ".264", 4);
            PRINT_MSG("New output File %s \n", output_file);
          }

          flagIsOutputExpected = 0;
          flagOutputReceived = 1;
        } else if (flagIsWidth) {
          in_width = atoi(argv[argn_dec]);
          flagIsWidth = 0;
        } else if (flagIsHeight) {
          in_height = atoi(argv[argn_dec]);
          flagIsHeight = 0;
        } else if (flagIsInputExpected) {
          input_file = reinterpret_cast<char *>(malloc(strlen(argv[argn_dec]) * sizeof(char) + 1));
          snprintf(input_file, strlen(argv[argn_dec])+1, "%s", argv[argn_dec]);
          flagIsInputExpected = 0;
          flagInputReceived = 1;
        } else if (flagIsFPS) {
          frame_rate = atoi(argv[argn_dec]);
          PRINT_MSG("user set: frame_rate=%d", frame_rate);
          if ((30 != frame_rate) || (60 != frame_rate)) {
            PRINT_ERR("frame_rate(%u) is not 30 or 60", frame_rate);
            display_help();
          }
          flagIsFPS = 0;
        } else if (flagIsControlRate) {
          OMX_U32 controlRate = atoi(argv[argn_dec]);
          s_eControlRate = vtest_parseControlRate(controlRate);
          flagIsControlRate = 0;
        }
      }
      argn_dec++;
    }

    /** output file name check and output file format check*/
    if (1 == flagOutputReceived) {
        if ((NULL == strstr(output_file, ".264")) && (NULL == strstr(output_file, ".265"))) {
          PRINT_ERR("You must specify appropriate out file of format, such as file.264 file.265\n");
          display_help();
        }
    }

    if (1 != flagInputReceived) {
      PRINT_ERR("You must specify appropriate input file \n");
      display_help();
    }

    if (NULL == input_file) {
        PRINT_ERR("You must specify appropriate input file \n");
        display_help();
    }
    infile = fopen(input_file, "rb");
    if (NULL == infile) {
        PRINT_ERR("Error in opening input file %s\n", input_file);
        return OMX_ErrorUndefined;
    }

    if (NULL == output_file) {
        PRINT_ERR("You must specify appropriate output file \n");
        display_help();
    }

    outfile = fopen(output_file, "wb");
    if (NULL == outfile) {
        PRINT_ERR("Error in opening output file %s\n", output_file);
        return OMX_ErrorUndefined;
    }

    return OMX_ErrorNone;
}

OMX_ERRORTYPE vtest_init_encode_component(void) {
    OMX_ERRORTYPE err;
    OMX_STRING full_component_name;
    OMX_PARAM_COMPONENTROLETYPE stRole;

    /* Initialize application private data */
    appPriv = reinterpret_cast<appPrivateType *>(malloc(sizeof(appPrivateType)));
    appPriv->encoderEventSem = reinterpret_cast<tsem_t *>(malloc(sizeof(tsem_t)));
    appPriv->eofSem =          reinterpret_cast<tsem_t *>(malloc(sizeof(tsem_t)));
    appPriv->sourceEventSem =  reinterpret_cast<tsem_t *>(malloc(sizeof(tsem_t)));
    tsem_init(appPriv->encoderEventSem, 0);
    tsem_init(appPriv->eofSem, 0);
    tsem_init(appPriv->sourceEventSem, 0);

    vtest_Config();
    PRINT_MSG("Init the Omx core\n");
    err = OMX_Init();
    if (err != OMX_ErrorNone) {
        PRINT_ERR("The OpenMAX core can not be initialized. Exiting...\n");
        return OMX_ErrorUndefined;
    } else {
        PRINT_MSG("Omx core is initialized \n");
    }

    full_component_name = (OMX_STRING) malloc(sizeof(char*) * OMX_MAX_STRINGNAME_SIZE);
    memset(full_component_name, 0x00, OMX_MAX_STRINGNAME_SIZE);

    if (OMX_VIDEO_CodingAVC == s_eEncCodec) {
      snprintf(full_component_name, OMX_MAX_STRINGNAME_SIZE, "%s", COMPONENT_ENC_AVC);
    } else if (OMX_VIDEO_CodingHEVC == s_eEncCodec) {
        snprintf(full_component_name, OMX_MAX_STRINGNAME_SIZE, "%s", COMPONENT_ENC_HEVC);
    }
    PRINT_MSG("The component selected for encoding is %s\n", full_component_name);

    /** getting video encoder handle */
    err = OMX_GetHandle(&appPriv->videoenchandle, full_component_name, NULL, &videoenccallbacks);
    if (err != OMX_ErrorNone) {
        PRINT_ERR("No video encoder component found. Exiting...\n");
        return OMX_ErrorUndefined;
    } else {
        PRINT_MSG("Found The component for encoding is %s\n", full_component_name);
    }

    OMX_INIT_STRUCT_SIZE(&stRole, OMX_PARAM_COMPONENTROLETYPE);
    err = OMX_GetParameter(appPriv->videoenchandle, OMX_IndexParamStandardComponentRole, &stRole);
    if (err != OMX_ErrorNone) {
      PRINT_ERR("The role set for this component can not be retrieved err = %i\n", err);
      return OMX_ErrorUndefined;
    } else {
        PRINT_MSG("success to OMX_GetParameter()\n");
    }
    PRINT_MSG("The current role is %s\n", stRole.cRole);
    return OMX_ErrorNone;
}

OMX_ERRORTYPE vtest_set_encode_params(void) {
    // vtest_VideoStreamParse();
    vtest_SetPort();
}

OMX_ERRORTYPE vtest_malloc_encode_buffer(void) {
    OMX_U32 jx = 0;
    OMX_ERRORTYPE err;

    /* set input buffer */
    pInBuffer = reinterpret_cast<OMX_BUFFERHEADERTYPE**>
        (malloc(m_nInputBufferCount*sizeof(OMX_BUFFERHEADERTYPE *)));
    if (NULL == pInBuffer) {
        PRINT_ERR("fail to malloc pInBuffer");
        return OMX_ErrorUndefined;
    }

    pOutBuffer = reinterpret_cast<OMX_BUFFERHEADERTYPE**>
        (malloc(m_nOutputBufferCount*sizeof(OMX_BUFFERHEADERTYPE *)));
    if (NULL == pOutBuffer) {
        PRINT_ERR("fail to malloc pOutBuffer");
        return OMX_ErrorUndefined;
    }

    for (jx=0; jx < m_nInputBufferCount; jx++) {
        pInBuffer[jx] = NULL;
        err = OMX_AllocateBuffer(appPriv->videoenchandle, &pInBuffer[jx], 0, NULL, buffer_in_size);
        RET_CHECK(OMX_ErrorNone != err);
    }
    PRINT_MSG("finish to allocate inBuf");

    for (jx=0; jx < m_nOutputBufferCount; jx++) {
        pOutBuffer[jx] = NULL;
        err =
        OMX_AllocateBuffer(appPriv->videoenchandle, &pOutBuffer[jx], 1, NULL, buffer_out_size);
        RET_CHECK(OMX_ErrorNone != err);
    }
    PRINT_MSG("finish to allocate outBuf");
    return OMX_ErrorNone;
}

OMX_ERRORTYPE vtest_start_proc_data(void) {
    OMX_U32 jx = 0;
    OMX_ERRORTYPE err;

    for (jx=0; jx < m_nOutputBufferCount; jx++) {
        err = OMX_FillThisBuffer(appPriv->videoenchandle, pOutBuffer[jx]);
        RET_CHECK(OMX_ErrorNone != err);
    }
    PRINT_MSG("finish to  OMX_FillThisBuffer()");

    for (jx=0; jx < m_nInputBufferCount; jx++) {
        char *yuv = reinterpret_cast<char *>(pInBuffer[jx]->pBuffer);
        int i, lscanl, lstride, cscanl, cstride;
        int result = 0;
        pInBuffer[jx]->nFilledLen = 0;

        lstride = VENUS_Y_STRIDE(COLOR_FMT_NV12, in_width);
        lscanl = VENUS_Y_SCANLINES(COLOR_FMT_NV12, in_height);
        cstride = VENUS_UV_STRIDE(COLOR_FMT_NV12, in_width);
        cscanl = VENUS_UV_SCANLINES(COLOR_FMT_NV12, in_height);
        for (i = 0; i < in_height; i++) {
            result += fread(yuv, 1, in_width, infile);
            yuv += lstride;
        }
        yuv = reinterpret_cast<char *>(pInBuffer[jx]->pBuffer + (lscanl * lstride));
        for (i = 0; i < ((in_height + 1) >> 1); i++) {
            result += fread(yuv, 1, in_width, infile);
            yuv += cstride;
        }
        pInBuffer[jx]->nFilledLen = VENUS_BUFFER_SIZE(COLOR_FMT_NV12, in_width, in_height);
        pInBuffer[jx]->nOffset = 0;
    }
    PRINT_MSG("finish to fread data into pInBuffer");

    for (jx=0; jx < m_nInputBufferCount; jx++) {
        err = OMX_EmptyThisBuffer(appPriv->videoenchandle, pInBuffer[jx]);
        RET_CHECK(OMX_ErrorNone != err);
    }
    PRINT_MSG("finish to OMX_EmptyThisBuffer pInBuffer");

    return OMX_ErrorNone;
}

OMX_ERRORTYPE vtest_free_encode_buffer(void) {
    OMX_U32 jx = 0;
    OMX_ERRORTYPE err;

    /** freeing buffers of video encoder input ports */
    PRINT_MSG("Free Video enc input ports\n");
    for (jx=0; jx < m_nInputBufferCount; jx++) {
        err = OMX_FreeBuffer(appPriv->videoenchandle, 0, pInBuffer[jx]);
        RET_CHECK(OMX_ErrorNone != err);
        pInBuffer[jx] = NULL;
    }
    free(pInBuffer);
    pInBuffer = NULL;

    PRINT_MSG("Free Video enc output ports\n");
    for (jx=0; jx < m_nOutputBufferCount; jx++) {
        err = OMX_FreeBuffer(appPriv->videoenchandle, 1, pOutBuffer[jx]);
        RET_CHECK(OMX_ErrorNone != err);
        pOutBuffer[jx] = NULL;
    }
    free(pOutBuffer);
    pOutBuffer = NULL;

    return OMX_ErrorNone;
}
OMX_ERRORTYPE vtest_deinit_encode_component(void) {
    PRINT_MSG("start to release  components.");

    OMX_FreeHandle(appPriv->videoenchandle);
    OMX_Deinit();

    free(appPriv->encoderEventSem);
    free(appPriv->sourceEventSem);
    free(appPriv->eofSem);
    free(appPriv);

    /** closing the output file */
    if (NULL != outfile) {
        fclose(outfile);
        outfile = NULL;
    }
    /** closing the input file */
    if (NULL != infile) {
        fclose(infile);
        infile = NULL;
    }
    PRINT_MSG("finish to release  components.");
    return OMX_ErrorNone;
}

int main(int argc, char** argv) {
    OMX_ERRORTYPE err;
    int data_read;
    int jx = 0;

    err = vtest_check_user_params(argc, argv);
    if (OMX_ErrorNone != err) {
        PRINT_MSG("fail to vtest_check_user_params()");
        exit(1);
    }

    vtest_init_encode_component();

    vtest_set_encode_params();

    err = vtest_malloc_encode_buffer();
    if (OMX_ErrorNone != err) {
        vtest_deinit_encode_component();
        return OMX_ErrorUndefined;
    }

    /** sending command to video encoder component to go to idle state */
    err = OMX_SendCommand(appPriv->videoenchandle, OMX_CommandStateSet, OMX_StateIdle, NULL);
    RET_CHECK(OMX_ErrorNone != err);
    PRINT_MSG("locking on idle state");
    tsem_down(appPriv->encoderEventSem);

    /** sending command to video encoder component to go to executing state */
    err = OMX_SendCommand(appPriv->videoenchandle, OMX_CommandStateSet, OMX_StateExecuting, NULL);
    RET_CHECK(OMX_ErrorNone != err);
    PRINT_MSG("locking on Executing statue");
    tsem_down(appPriv->encoderEventSem);

    vtest_start_proc_data();
    PRINT_MSG("Waiting for  EOS");
    tsem_down(appPriv->eofSem);

    err = OMX_SendCommand(appPriv->videoenchandle, OMX_CommandStateSet, OMX_StateIdle, NULL);
    RET_CHECK(OMX_ErrorNone != err);
    PRINT_MSG("Wait to idle state. Then send cmd: load");
    tsem_down(appPriv->encoderEventSem);
    PRINT_MSG("start to send cmd: load");

    /** sending command to all components to go to loaded state */
    err = OMX_SendCommand(appPriv->videoenchandle, OMX_CommandStateSet, OMX_StateLoaded, NULL);
    RET_CHECK(OMX_ErrorNone != err);

    vtest_free_encode_buffer();

    PRINT_MSG("Wait to release sem to free Handle");
    tsem_down(appPriv->encoderEventSem);

    vtest_deinit_encode_component();
    PRINT_MSG("\n finish to encode file \n");

    return 0;
}

/** Callbacks implementation of the video encoder component*/
OMX_ERRORTYPE videoencEventHandler(
    OMX_OUT OMX_HANDLETYPE hComponent,
    OMX_OUT OMX_PTR pAppData,
    OMX_OUT OMX_EVENTTYPE eEvent,
    OMX_OUT OMX_U32 Data1,
    OMX_OUT OMX_U32 Data2,
    OMX_OUT OMX_PTR pEventData) {

    OMX_ERRORTYPE err = OMX_ErrorNone;

    DEBUG(DEB_LEV_SIMPLE_SEQ, "event=%d, in %s callback\n", eEvent, __func__);

    if (eEvent == OMX_EventCmdComplete) {
        if (Data1 == OMX_CommandStateSet) {
            DEBUG(DEB_LEV_SIMPLE_SEQ, "State changed in ");
            switch (Data2) {
                case OMX_StateInvalid:
                DEBUG(DEB_LEV_SIMPLE_SEQ, "OMX_StateInvalid\n");
                break;

                case OMX_StateLoaded:
                DEBUG(DEB_LEV_SIMPLE_SEQ, "OMX_StateLoaded\n");
                break;

                case OMX_StateIdle:
                DEBUG(DEB_LEV_SIMPLE_SEQ, "OMX_StateIdle\n");
                break;

                case OMX_StateExecuting:
                DEBUG(DEB_LEV_SIMPLE_SEQ, "OMX_StateExecuting\n");
                break;

                case OMX_StatePause:
                DEBUG(DEB_LEV_SIMPLE_SEQ, "OMX_StatePause\n");
                break;

                case OMX_StateWaitForResources:
                DEBUG(DEB_LEV_SIMPLE_SEQ, "OMX_StateWaitForResources\n");
                break;

                default:
                break;
            }
            tsem_up(appPriv->encoderEventSem);
        } else if (OMX_CommandPortEnable || OMX_CommandPortDisable) {
            DEBUG(DEB_LEV_SIMPLE_SEQ, "In %s Received Port Enable/Disable Event\n", __func__);
            tsem_up(appPriv->encoderEventSem);
        } else if (OMX_CommandFlush == Data1) {
            DEBUG(DEB_LEV_SIMPLE_SEQ, "In %s Received OMX_CommandFlush Event\n", __func__);
        }
    } else if (eEvent == OMX_EventPortSettingsChanged) {
        DEBUG(DEB_LEV_SIMPLE_SEQ, "\n port settings change event handler in %s \n", __func__);

    } else if (eEvent == OMX_EventBufferFlag) {
        DEBUG(DEFAULT_MESSAGES, "In %s OMX_BUFFERFLAG_EOS\n", __func__);
        if (static_cast<int>(Data2) == OMX_BUFFERFLAG_EOS) {
            tsem_up(appPriv->eofSem);
        }
    } else {
        DEBUG(DEB_LEV_SIMPLE_SEQ, "Param1 is 0x%x\n", Data1);
        DEBUG(DEB_LEV_SIMPLE_SEQ, "Param2 is 0x%x\n", Data2);
    }

    return err;
}

OMX_ERRORTYPE videoencEmptyBufferDone(
  OMX_OUT OMX_HANDLETYPE hComponent,
  OMX_OUT OMX_PTR pAppData,
  OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer) {
    static int iBufferDropped = 0;

    OMX_ERRORTYPE err;
    int data_read;
    // PRINT_MSG("Hi there, I am in the %s callback.", __func__);

    char *yuv = reinterpret_cast<char *>(pBuffer->pBuffer);
    int i, lscanl, lstride, cscanl, cstride;
    int result = 0;
    pBuffer->nFilledLen = 0;

    lstride = VENUS_Y_STRIDE(COLOR_FMT_NV12, in_width);
    lscanl = VENUS_Y_SCANLINES(COLOR_FMT_NV12, in_height);
    cstride = VENUS_UV_STRIDE(COLOR_FMT_NV12, in_width);
    cscanl = VENUS_UV_SCANLINES(COLOR_FMT_NV12, in_height);

    for (i = 0; i < in_height; i++) {
        result += fread(yuv, 1, in_width, infile);
        yuv += lstride;
    }
    yuv = reinterpret_cast<char *>(pBuffer->pBuffer + (lscanl * lstride));
    for (i = 0; i < ((in_height + 1) >> 1); i++) {
        result += fread(yuv, 1, in_width, infile);
        yuv += cstride;
    }

    if (result < m_frameSize) {
        PRINT_MSG("no more input data,nFlags=%d, pBuffer=%p", pBuffer->nFlags, pBuffer);
        tsem_up(appPriv->eofSem);
        bEOS = OMX_TRUE;

        return OMX_ErrorNone;
    }

    pBuffer->nFilledLen = VENUS_BUFFER_SIZE(COLOR_FMT_NV12, in_width, in_height);
    pBuffer->nOffset = 0;
    PRINT_MSG("Empty buffer %p ", pBuffer);
    err = OMX_EmptyThisBuffer(hComponent, pBuffer);
    RET_CHECK(OMX_ErrorNone != err);

    return OMX_ErrorNone;
}

OMX_ERRORTYPE videoencFillBufferDone(
  OMX_OUT OMX_HANDLETYPE hComponent,
  OMX_OUT OMX_PTR pAppData,
  OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer) {
  OMX_ERRORTYPE err;
  // PRINT_MSG("Hi there, I am in the %s callback.", __func__);

  if (pBuffer != NULL) {
    if (!bEOS) {
      if ((pBuffer->nFilledLen > 0)) {
          PRINT_MSG("Now need fwrite %d bytes to file", pBuffer->nFilledLen);
          fwrite(pBuffer->pBuffer, sizeof(char),  pBuffer->nFilledLen, outfile);
          pBuffer->nFilledLen = 0;
      }
      if (pBuffer->nFlags == OMX_BUFFERFLAG_EOS) {
        PRINT_MSG("get EOS flag:%x Calling Empty This Buffer", (int)pBuffer->nFlags);
        bEOS = OMX_TRUE;
      }
      if (!bEOS) {
        err = OMX_FillThisBuffer(hComponent, pBuffer);
      }
    } else {
      PRINT_MSG("nFlags=%x Dropping Empty This Buffer:%p", (int)pBuffer->nFlags, pBuffer);
    }
  } else {
    PRINT_ERR("Ouch!  had NULL buffer to output...");
  }

  return OMX_ErrorNone;
}
