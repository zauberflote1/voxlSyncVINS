/**
  @file vtest/encode/src/video_encode.cpp
  
  $Date$
  Revision $Rev$
  Author $Author$
*/
#ifndef _VIDEO_ENCODE_H_
#define _VIDEO_ENCODE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <pthread.h>
#include <ctype.h>
#include <tsemaphore.h>
#include <user_debug_levels.h>

#include <OMX_Component.h>
#include <OMX_Types.h>

#include <VideoStreamParser.h>
#include "OMX_Core.h"
#include "OMX_Video.h"
#include "OMX_QCOMExtns.h"

#include "common.h"


/* Application's private data */
typedef struct appPrivateType {
  tsem_t* encoderEventSem;
  tsem_t* eofSem;
  tsem_t* sourceEventSem;
  OMX_HANDLETYPE videosrchandle;
  OMX_HANDLETYPE videoenchandle;
}appPrivateType;

/* Callback prototypes for video source */
OMX_ERRORTYPE videosrcEventHandler(
  OMX_OUT OMX_HANDLETYPE hComponent,
  OMX_OUT OMX_PTR pAppData,
  OMX_OUT OMX_EVENTTYPE eEvent,
  OMX_OUT OMX_U32 Data1,
  OMX_OUT OMX_U32 Data2,
  OMX_OUT OMX_PTR pEventData);

OMX_ERRORTYPE videosrcFillBufferDone(
  OMX_OUT OMX_HANDLETYPE hComponent,
  OMX_OUT OMX_PTR pAppData,
  OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer);

/* Callback prototypes for video encoder */
OMX_ERRORTYPE videoencEventHandler(
  OMX_OUT OMX_HANDLETYPE hComponent,
  OMX_OUT OMX_PTR pAppData,
  OMX_OUT OMX_EVENTTYPE eEvent,
  OMX_OUT OMX_U32 Data1,
  OMX_OUT OMX_U32 Data2,
  OMX_OUT OMX_PTR pEventData);

OMX_ERRORTYPE videoencEmptyBufferDone(
  OMX_OUT OMX_HANDLETYPE hComponent,
  OMX_OUT OMX_PTR pAppData,
  OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer);

OMX_ERRORTYPE videoencFillBufferDone(
  OMX_OUT OMX_HANDLETYPE hComponent,
  OMX_OUT OMX_PTR pAppData,
  OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer);

/** function prototype declaration */


#ifdef __cplusplus
}
#endif

#endif  // _VIDEO_ENCODE_H_
